from Testing import testDummySet1, testDummySet2, testConnect4, testCar

testDummySet1()
testDummySet2()
testConnect4()
testCar()